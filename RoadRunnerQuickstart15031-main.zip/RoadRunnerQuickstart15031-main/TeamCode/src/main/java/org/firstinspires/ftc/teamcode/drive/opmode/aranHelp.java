package org.firstinspires.ftc.teamcode.drive.opmode;

import com.acmerobotics.roadrunner.geometry.Pose2d;
import com.qualcomm.robotcore.eventloop.opmode.Autonomous;
import com.qualcomm.robotcore.eventloop.opmode.LinearOpMode;
import com.qualcomm.robotcore.eventloop.opmode.TeleOp;
import com.qualcomm.robotcore.hardware.CRServo;
import com.qualcomm.robotcore.hardware.DcMotorEx;

@TeleOp(name = "aranHelp")
public class aranHelp extends LinearOpMode{
    DcMotorEx leftFront, leftRear, rightRear, rightFront;

    @Override
    public void runOpMode() throws InterruptedException {
        leftFront = hardwareMap.get(DcMotorEx.class, "leftFront");

        waitForStart();

        if (gamepad1.a) {
            moveForward(.1);
        } else if (gamepad1.b) {
            moveForward(.1);
        }
    }

    public void moveForward(double power) {
        leftFront.setPower(power);
    }
    public void moveBack(double power) {
        leftFront.setPower(-power);
    }
    public void stopMotion() {
        leftFront.setPower(0);
    }
}
