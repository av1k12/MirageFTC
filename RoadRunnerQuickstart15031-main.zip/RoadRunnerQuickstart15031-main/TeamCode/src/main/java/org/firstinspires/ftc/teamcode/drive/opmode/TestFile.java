package org.firstinspires.ftc.teamcode.drive.opmode;

import com.acmerobotics.roadrunner.geometry.Pose2d;
import com.qualcomm.robotcore.eventloop.opmode.LinearOpMode;
import com.qualcomm.robotcore.eventloop.opmode.TeleOp;
import com.qualcomm.robotcore.hardware.CRServo;
import com.qualcomm.robotcore.hardware.Servo;
import com.qualcomm.robotcore.hardware.DcMotor;

import org.firstinspires.ftc.teamcode.drive.SampleMecanumDrive;

@TeleOp(group = "drive")
public class TestFile extends LinearOpMode {
    private CRServo servo; // Declare the servo
    private CRServo servo1;
    private Servo servo2;

    @Override
    public void runOpMode() throws InterruptedException {
        // Initialize the mecanum drive
        SampleMecanumDrive drive = new SampleMecanumDrive(hardwareMap);
        drive.setMode(DcMotor.RunMode.RUN_WITHOUT_ENCODER);

        // Initialize the servo
        servo = hardwareMap.get(CRServo.class, "servo");
        servo1 = hardwareMap.get(CRServo.class, "servo1");
        servo2 = hardwareMap.get(Servo.class, "servo2");

        waitForStart();

        while (opModeIsActive()) {
            // Mecanum drive control
            drive.setWeightedDrivePower(
                    new Pose2d(
                            -gamepad1.left_stick_y,  // Forward/backward
                            -gamepad1.left_stick_x,  // Strafe left/right
                            -gamepad1.right_stick_x  // Rotate
                    )
            );

            drive.update();

            // Servo control
            if (gamepad1.a) {
                servo.setPower(1); // Move servo forward
                servo1.setPower(-1);
                servo2.setPosition(.03);
            } else if (gamepad1.b) {
                servo.setPower(-1); // Move servo backward
                servo1.setPower(1);
                servo2.setPosition(.1);
            } else {
                servo.setPower(0); // Stop servo
                servo1.setPower(0);
                servo2.setPosition(.2);
            }

            // Display telemetry data
            Pose2d poseEstimate = drive.getPoseEstimate();
            telemetry.addData("x", poseEstimate.getX());
            telemetry.addData("y", poseEstimate.getY());
            telemetry.addData("heading", poseEstimate.getHeading());
            telemetry.update();
        }
    }
}
