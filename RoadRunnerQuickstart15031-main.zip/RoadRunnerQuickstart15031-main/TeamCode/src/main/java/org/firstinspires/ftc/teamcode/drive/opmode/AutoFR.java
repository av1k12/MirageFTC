package org.firstinspires.ftc.teamcode.drive.opmode;

import com.acmerobotics.roadrunner.geometry.Pose2d;
import com.acmerobotics.roadrunner.geometry.Vector2d;
import com.acmerobotics.roadrunner.trajectory.Trajectory;
import com.acmerobotics.roadrunner.trajectory.TrajectoryBuilder;
import com.qualcomm.robotcore.eventloop.opmode.Autonomous;
import com.qualcomm.robotcore.eventloop.opmode.LinearOpMode;
import org.firstinspires.ftc.teamcode.drive.SampleMecanumDrive;

@Autonomous(name = "AutoDawg")
public class AutoFR extends LinearOpMode {
    @Override
    public void runOpMode() {
        SampleMecanumDrive drive = new SampleMecanumDrive(hardwareMap);
        Pose2d startPose = new Pose2d(-7.69,62.26,Math.toRadians(90));
        drive.setPoseEstimate(startPose);
        // Trajectory 1
        Trajectory trajectory1 = drive.trajectoryBuilder(startPose)
                .lineTo(new Vector2d(4, 28))
                .build();

        Trajectory trajectory4 = drive.trajectoryBuilder(trajectory1.end())
                .forward(15)
                .build();

        Trajectory trajectory2 = drive.trajectoryBuilder(trajectory4.end())
                .splineToSplineHeading(new Pose2d(-46, 15,Math.toRadians(-90)),Math.toRadians(-150))
                .build();

        Trajectory trajectory3 = drive.trajectoryBuilder(trajectory2.end())
                .back(50)
                .build();

        Trajectory trajectory5 = drive.trajectoryBuilder(trajectory3.end())
                .forward(37)
                .build();

        Trajectory trajectory6 = drive.trajectoryBuilder(trajectory5.end())
                .strafeRight(8)
                .build();

        Trajectory trajectory7 = drive.trajectoryBuilder(trajectory6.end())
                .back(37)
                .build();

        Trajectory trajectory8 = drive.trajectoryBuilder(trajectory7.end())
                .forward(37)
                .build();

        Trajectory trajectory9 = drive.trajectoryBuilder(trajectory8.end())
                .strafeRight(8)
                .build();

        Trajectory trajectory10 = drive.trajectoryBuilder(trajectory9.end())
                .back(37)
                .build();

        // Trajectory 2
        waitForStart();

        if (isStopRequested()) return;

        // Follow the trajectories sequentially
        drive.followTrajectory(trajectory1);
        drive.followTrajectory(trajectory4);
        drive.followTrajectory(trajectory2);
        drive.followTrajectory(trajectory3);
        drive.followTrajectory(trajectory5);
        drive.followTrajectory(trajectory6);
        drive.followTrajectory(trajectory7);
        drive.followTrajectory(trajectory8);
        drive.followTrajectory(trajectory9);
        drive.followTrajectory(trajectory10);

    }
}
